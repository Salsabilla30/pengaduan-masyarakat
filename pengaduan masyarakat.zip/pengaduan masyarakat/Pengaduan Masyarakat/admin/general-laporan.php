<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DateTime Picker Example</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
  

</head>
<!-- DataTales Example -->
<body>
<div class="card shadow mb-4">
<div class="card-header py-3">
<h6 class="m-0 font-weight-bold text-primary">Filter Laporan</h6>
</div>
<div class="card-body" style="font-size: 14px">
<div class="col-lg-6">
<div class="p-2">
<form class="user" method="get" action="print.php">
<div class="form-group">
    <input type="text" id="datetime"  placeholder="Tanggal awal" name="tgl_awal">

    <script>
        // Initialize Flatpickr
        flatpickr("#datetime", {
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            time_24hr: true
        });
    </script>
</div>
<div class="form-group">
<input type="text" id="datetime"  placeholder="Tanggal akhir" name="tgl_akhir">
    <script>
        // Initialize Flatpickr
        flatpickr("#datetime", {
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            time_24hr: true
        });
    </script>
</div>
<div class="form-group">
<label for="cars">Status Laporan</label>
<select class="form-select form-select-sm" aria-label=".form-select-sm example" name="status">
<option value="1">Semua</option>
<option value="proses">Proses</option>
<option value="0">Belum Diproses</option>
</select>
</div>
<button type="submit" class="btn btn-primary btn-user btn-block">
Generate Laporan
</button>
</form>
</div>
</div>
</div>
</div>
</body>