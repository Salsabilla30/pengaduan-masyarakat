<?php
// Memanggil library FPDF 
require('../library/fpdf.php');
include('../koneksi.php');

// Instance object dan memberikan pengaturan halaman PDF
$pdf = new FPDF('L', 'mm', 'A4');
$pdf->AddPage();

$pdf->SetFont('Times', 'B', 13);
$pdf->Cell(250, 10, 'DATA PENGADUAN MASYARAKAT - DN', 0, 0, 'C');

$pdf->Cell(10, 15, '', 0, 1);
$pdf->SetFont('Times', 'B', 9);

$pdf->Cell(10, 7, 'NO', 1, 0, 'C');
$pdf->Cell(20, 7, 'ID_Pengaduan', 1, 0, 'C');
$pdf->Cell(35, 7, 'Tanggal Pengaduan', 1, 0, 'C');
$pdf->Cell(25, 7, 'ΝΙΚ', 1, 0, 'C');
$pdf->Cell(50, 7, 'Isi Laporan', 1, 0, 'C');
$pdf->Cell(55, 7, 'Foto', 1, 0, 'C');
$pdf->Cell(35, 7, 'Tanggapan', 1, 0, 'C');
$pdf->Cell(35, 7, 'Status', 1, 0, 'C');
$pdf->Cell(10, 7, '', 0, 1);
$pdf->SetFont('Times', '', 10); 

$tgl_awal = $_GET['tgl_awal'];
$tgl_akhir = $_GET['tgl_akhir'];
$status = $_GET['status']; 

// Kueri SQL yang diperbaiki
$sql = "SELECT * FROM pengaduan WHERE status='$status' AND tgl_pengaduan BETWEEN '$tgl_awal' AND '$tgl_akhir'";
$query = mysqli_query($koneksi, $sql);
$no = 1;

while ($data = mysqli_fetch_array($query)) {
    $pdf->Cell(10, 6, $no++, 1, 0, 'C');
    $pdf->Cell(20, 6, $data['id_pengaduan'], 1, 0);
    $pdf->Cell(35, 6, $data['tgl_pengaduan'], 1, 0);
    $pdf->Cell(25, 6, $data['nik'], 1, 0);
    $pdf->Cell(50, 6, $data['isi_laporan'], 1, 0);
    $pdf->Cell(55, 6, $data['foto'], 1, 0);

    // Kueri untuk tanggapan
    $sql1 = "SELECT * FROM tanggapan WHERE id_pengaduan = '" .$data['id_pengaduan'] . "'";
    $query1 = mysqli_query($koneksi, $sql1);

    if ($data1 = mysqli_fetch_array($query1)) {
        $pdf->Cell(35, 6, $data1['tanggapan'], 1, 0);
    } else {
        $pdf->Cell(35, 6, "-", 1, 0);
    }

    $pdf->Cell(35, 6, $data['status'], 1, 1);
}

$pdf->Output();
?>
